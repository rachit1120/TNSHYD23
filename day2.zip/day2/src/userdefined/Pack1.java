package userdefined;

public class Pack1 {
	public void msg() {
		 System.out.println("HELLO");
	}
}
