package userdefined;

public class Pack2 {
	public void msg() {
		System.out.println("HELLO RACHIT");
	}

}
