package packagemain;
import userdefined.*;
import subpackage.*;

public class Pack4 {
 public static void main(String[] args)
 {
	 Pack1 obj = new Pack1();
	 Pack2 obj1 = new Pack2();
	 Pack3 obj2 = new Pack3();
	 obj.msg();
	 obj1.msg();
	 obj2.msg();
 }
}
