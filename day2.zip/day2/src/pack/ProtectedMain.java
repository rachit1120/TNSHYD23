package pack;
import day2.*;

public class ProtectedMain extends Protected {

	public static void main(String[] args) {
		ProtectedMain p1 = new ProtectedMain();
		System.out.println(p1.a);

	}

}
