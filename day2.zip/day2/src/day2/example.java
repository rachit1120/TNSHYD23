package day2;

public class example {

	public static void main(String[] args) {
		System.out.println("HELLO");

	}

}
