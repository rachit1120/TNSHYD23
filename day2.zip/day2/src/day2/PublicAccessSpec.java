package day2;

public class PublicAccessSpec {
  public int a=88;
  
}
