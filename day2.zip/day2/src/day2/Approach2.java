package day2;

public class Approach2 {
	int a=10;
    static int b=20;
    int display() {
    	return 10;
    }
  static void display1() {
	  System.out.println("Hello");
  }
}
