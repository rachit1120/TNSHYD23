package day2;

public class PrivateAccessSpec {
	private int a=50;
	public static void main(String[] args) {
		PrivateAccessSpec a1 = new PrivateAccessSpec();
		System.out.println(a1.a);
	}


}
