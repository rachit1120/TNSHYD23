package day2;

public class PuublicAccessSpecMain {
	
     public static void main(String[] args) {
    	 PublicAccessSpec a1 = new PublicAccessSpec();
 		System.out.println(a1.a);
	}
}
