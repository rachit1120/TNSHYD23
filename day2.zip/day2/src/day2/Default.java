package day2;

public class Default {
	int a=50;
public static void main(String[] args) {
	Default a1 = new Default();
	System.out.println(a1.a);
} 	

}
