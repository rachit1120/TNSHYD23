package day2;

public class Protected {
	protected int a= 66;

}
