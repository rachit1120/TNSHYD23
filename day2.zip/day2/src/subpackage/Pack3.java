package subpackage;

public class Pack3 {
	public void msg() {
		System.out.println("HELLO JAVA");
	} 
}
